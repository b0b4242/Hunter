package com.jp.dealhunter

object Diag {
    @Volatile var events = 0
    @Volatile var scans = 0
    @Volatile var nullRoots = 0
    @Volatile var nodes = 0
    @Volatile var parsed = 0
    @Volatile var shots = 0
    @Volatile var ocrLines = 0
    @Volatile var lastErr = "-"
    @Volatile var lastPkg = "-"
    private val seen = LinkedHashSet<String>()

    @Synchronized fun sample(s: String) {
        if (s.length < 3 || s.length > 200) return
        if (seen.add(s) && seen.size > 150) seen.remove(seen.first())
    }

    @Synchronized fun dump(): String =
        "Événements reçus : $events\nDernier paquet : $lastPkg\nLectures d'écran (arbre) : $scans\n" +
        "Écrans illisibles : $nullRoots\nNœuds lus : $nodes\nCaptures d'écran : $shots\n" +
        "Lignes lues par OCR : $ocrLines\nAnnonces reconnues : $parsed\nDernière erreur : $lastErr\n\n" +
        "--- Textes vus ---\n" + seen.joinToString("\n")

    @Synchronized fun reset() {
        events = 0; scans = 0; nullRoots = 0; nodes = 0; parsed = 0; shots = 0; ocrLines = 0; lastErr = "-"; seen.clear()
    }
}
