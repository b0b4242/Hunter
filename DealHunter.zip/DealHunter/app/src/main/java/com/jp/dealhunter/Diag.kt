package com.jp.dealhunter

object Diag {
    @Volatile var events = 0
    @Volatile var scans = 0
    @Volatile var nullRoots = 0
    @Volatile var nodes = 0
    @Volatile var parsed = 0
    @Volatile var lastPkg = "-"
    private val seen = LinkedHashSet<String>()

    @Synchronized fun sample(s: String) {
        if (s.length < 3 || s.length > 200) return
        if (seen.add(s) && seen.size > 150) seen.remove(seen.first())
    }

    @Synchronized fun dump(): String =
        "Événements reçus : $events\nDernier paquet : $lastPkg\nLectures d'écran : $scans\n" +
        "Écrans illisibles : $nullRoots\nNœuds lus : $nodes\nAnnonces reconnues : $parsed\n\n" +
        "--- Textes vus (Facebook) ---\n" + seen.joinToString("\n")

    @Synchronized fun reset() { events = 0; scans = 0; nullRoots = 0; nodes = 0; parsed = 0; seen.clear() }
}
