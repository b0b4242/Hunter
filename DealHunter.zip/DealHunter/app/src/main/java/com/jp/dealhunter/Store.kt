package com.jp.dealhunter

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Deal(
    val key: String, val title: String, val price: Double, val location: String,
    val resale: Double, val profit: Double, val margin: Double,
    val risks: String, val status: String
)

class Store(private val ctx: Context) {

    private val prefs = ctx.getSharedPreferences("dealhunter", Context.MODE_PRIVATE)

    var active: Boolean
        get() = prefs.getBoolean("active", false)
        set(v) = prefs.edit().putBoolean("active", v).apply()
    var priceBase: String
        get() = prefs.getString("priceBase", "# Une ligne par article : mot-clé=prix de revente\n# exemple : nintendo switch=220\n") ?: ""
        set(v) = prefs.edit().putString("priceBase", v).apply()
    var transport: Double
        get() = prefs.getFloat("transport", 3f).toDouble()
        set(v) = prefs.edit().putFloat("transport", v.toFloat()).apply()
    var feePct: Double
        get() = prefs.getFloat("feePct", 0f).toDouble()
        set(v) = prefs.edit().putFloat("feePct", v.toFloat()).apply()
    var minProfit: Double
        get() = prefs.getFloat("minProfit", 15f).toDouble()
        set(v) = prefs.edit().putFloat("minProfit", v.toFloat()).apply()

    private class Db(c: Context) : SQLiteOpenHelper(c, "deals.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE deals(k TEXT PRIMARY KEY, title TEXT, price REAL, location TEXT, " +
                "resale REAL, profit REAL, margin REAL, risks TEXT, status TEXT, ts INTEGER)"
            )
        }
        override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    }

    private val db by lazy { Db(ctx).writableDatabase }

    /** true si l'annonce est nouvelle (pas un doublon). */
    fun insertIfNew(d: Deal): Boolean {
        val cv = ContentValues().apply {
            put("k", d.key); put("title", d.title); put("price", d.price)
            put("location", d.location); put("resale", d.resale); put("profit", d.profit)
            put("margin", d.margin); put("risks", d.risks); put("status", "new")
            put("ts", System.currentTimeMillis())
        }
        return db.insertWithOnConflict("deals", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun setStatus(key: String, status: String) {
        db.execSQL("UPDATE deals SET status=? WHERE k=?", arrayOf(status, key))
    }

    fun list(includeIgnored: Boolean): List<Deal> {
        val where = if (includeIgnored) null else "status != 'ignored'"
        val c = db.query("deals", null, where, null, null, null, "profit DESC", "200")
        val out = ArrayList<Deal>()
        while (c.moveToNext()) {
            out.add(
                Deal(
                    c.getString(0), c.getString(1), c.getDouble(2), c.getString(3) ?: "",
                    c.getDouble(4), c.getDouble(5), c.getDouble(6), c.getString(7) ?: "", c.getString(8)
                )
            )
        }
        c.close()
        return out
    }

    fun clear() { db.execSQL("DELETE FROM deals") }
}
