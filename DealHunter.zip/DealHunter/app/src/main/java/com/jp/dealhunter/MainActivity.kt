package com.jp.dealhunter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var list: LinearLayout
    private lateinit var base: EditText
    private lateinit var transport: EditText
    private lateinit var fee: EditText
    private lateinit var minProfit: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { onClick() }
    }

    private fun field(label: String, value: String, parent: LinearLayout): EditText {
        parent.addView(TextView(this).apply { text = label; setPadding(0, dp(8), 0, 0) })
        return EditText(this).apply {
            setText(value); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }.also { parent.addView(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        root.addView(TextView(this).apply { text = "DealHunter"; textSize = 26f })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        root.addView(btn("1. Activer le service d'accessibilité") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        toggle = btn("2. Démarrer la session") {
            store.active = !store.active; refresh()
        }
        root.addView(toggle)
        root.addView(btn("3. Ouvrir Facebook") {
            val i = packageManager.getLaunchIntentForPackage("com.facebook.katana")
            if (i != null) startActivity(i) else Toast.makeText(this, "Facebook introuvable", Toast.LENGTH_SHORT).show()
        })

        root.addView(TextView(this).apply { text = "\nBase de prix (mot-clé=prix de revente)"; textSize = 16f })
        base = EditText(this).apply { setText(store.priceBase); minLines = 6; gravity = android.view.Gravity.TOP }
        root.addView(base)
        transport = field("Coût de transport par achat", store.transport.toString(), root)
        fee = field("Frais de revente (%)", store.feePct.toString(), root)
        minProfit = field("Profit minimum pour notifier", store.minProfit.toString(), root)
        root.addView(btn("Enregistrer les réglages") {
            store.priceBase = base.text.toString()
            store.transport = transport.text.toString().toDoubleOrNull() ?: 0.0
            store.feePct = fee.text.toString().toDoubleOrNull() ?: 0.0
            store.minProfit = minProfit.text.toString().toDoubleOrNull() ?: 0.0
            Toast.makeText(this, "Enregistré", Toast.LENGTH_SHORT).show()
        })

        root.addView(TextView(this).apply { text = "\nAnnonces repérées (meilleures en premier)"; textSize = 16f })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(btn("Vider l'historique") {
            AlertDialog.Builder(this).setMessage("Supprimer toutes les annonces sauvegardées ?")
                .setPositiveButton("Oui") { _, _ -> store.clear(); refresh() }
                .setNegativeButton("Non", null).show()
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun refresh() {
        status.text = "Service : " + (if (serviceEnabled()) "activé ✓" else "désactivé ✗") +
            "\nSession : " + (if (store.active) "en cours" else "arrêtée")
        toggle.text = if (store.active) "2. Arrêter la session" else "2. Démarrer la session"

        list.removeAllViews()
        for (d in store.list(false)) {
            val tv = TextView(this).apply {
                setPadding(0, dp(8), 0, dp(8))
                val mark = when (d.status) { "bought" -> "✅ "; else -> "" }
                text = "$mark${d.title}\n${d.price.toInt()} → ~${d.resale.toInt()} · profit ~${d.profit.toInt()} " +
                    "(${d.margin.toInt()} %)" + (if (d.location.isNotEmpty()) " · ${d.location}" else "") +
                    (if (d.risks.isNotEmpty()) "\n⚠ ${d.risks}" else "")
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle(d.title)
                        .setItems(arrayOf("Acheté", "Ignorer")) { _, w ->
                            store.setStatus(d.key, if (w == 0) "bought" else "ignored"); refresh()
                        }.show()
                }
            }
            list.addView(tv)
            list.addView(View(this).apply {
                setBackgroundColor(0x22000000); layoutParams = LinearLayout.LayoutParams(-1, 1)
            })
        }
    }
}
