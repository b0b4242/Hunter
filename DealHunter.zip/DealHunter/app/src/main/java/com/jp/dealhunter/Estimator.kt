package com.jp.dealhunter

data class Listing(val title: String, val price: Double, val location: String)

object Estimator {

    private val priceRe = Regex(
        """^(?:(?:CA|US|C|A)?[$€£]\s?([\d\s.,]+)|([\d\s.,]+)\s?(?:[$€£]|CAD|EUR))$""",
        RegexOption.IGNORE_CASE
    )
    private val freeRe = Regex("""^(gratuit|free)$""", RegexOption.IGNORE_CASE)

    private val badWords = listOf(
        "pour pièces", "pour pieces", "for parts", "cassé", "casse", "brisé", "défectueux",
        "defectueux", "ne fonctionne pas", "ne marche pas", "hs ", "as is", "tel quel", "broken"
    )
    private val scamWords = listOf(
        "envoi", "livraison", "paypal", "virement", "western union", "dépôt d'abord", "depot d'abord", "zelle"
    )

    private fun number(raw: String): Double? {
        var n = raw.trim().replace("\u00a0", "").replace(" ", "")
        n = if (Regex(""",\d{1,2}$""").containsMatchIn(n)) n.replace(".", "").replace(',', '.')
        else n.replace(",", "")
        return n.toDoubleOrNull()
    }

    /** Les cartes Marketplace sont lues sous la forme « prix, titre, lieu ». */
    fun parse(s: String): Listing? {
        val parts = s.split(", ").map { it.trim() }
        if (parts.size < 2) return null
        val first = parts[0]
        val price = when {
            freeRe.matches(first) -> 0.0
            else -> {
                val m = priceRe.find(first) ?: return null
                number(m.groupValues[1].ifEmpty { m.groupValues[2] }) ?: return null
            }
        }
        val end = if (parts.size >= 3) parts.size - 1 else parts.size
        val title = parts.subList(1, end).joinToString(", ")
        if (title.length < 3) return null
        val loc = if (parts.size >= 3) parts.last() else ""
        return Listing(title, price, loc)
    }

    private fun baseLookup(base: String, title: String): Double? {
        val t = title.lowercase()
        var best: Pair<Int, Double>? = null
        for (line in base.lines()) {
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("#") || !l.contains("=")) continue
            val kw = l.substringBefore("=").trim().lowercase()
            val v = number(l.substringAfter("=").trim()) ?: continue
            if (kw.isNotEmpty() && t.contains(kw) && (best == null || kw.length > best.first)) best = kw.length to v
        }
        return best?.second
    }

    /** Retourne null si l'annonce n'est pas dans la base de prix et n'est pas gratuite. */
    fun evaluate(l: Listing, store: Store): Deal? {
        val resale = baseLookup(store.priceBase, l.title)
        if (resale == null && l.price > 0) return null
        val r = resale ?: 0.0
        val fees = r * store.feePct / 100.0
        val profit = if (resale == null) 0.0 else r - l.price - fees - store.transport
        val margin = if (l.price > 0) profit / l.price * 100.0 else 0.0

        val risks = ArrayList<String>()
        val t = l.title.lowercase() + " "
        if (badWords.any { t.contains(it) }) risks.add("état douteux")
        if (scamWords.any { t.contains(it) }) risks.add("arnaque possible")
        if (resale != null && l.price > 0 && l.price < r * 0.25) risks.add("trop beau pour être vrai")
        if (resale == null) risks.add("prix de revente inconnu")

        val key = l.title.lowercase().filter { it.isLetterOrDigit() } + "|" + l.price.toInt()
        return Deal(key, l.title, l.price, l.location, r, profit, margin, risks.joinToString(", "), "new")
    }
}
