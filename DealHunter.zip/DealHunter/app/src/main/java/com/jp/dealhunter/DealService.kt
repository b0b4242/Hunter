package com.jp.dealhunter

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class DealService : AccessibilityService() {

    private lateinit var store: Store
    private var lastScan = 0L
    private var nodeCount = 0
    private var pendingPrice: Double? = null
    private var pendingAge = 0

    override fun onServiceConnected() {
        store = Store(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("deals", "Bonnes affaires", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !::store.isInitialized) return
        Diag.events++
        val pkg = e.packageName?.toString() ?: return
        if (pkg != packageName && pkg != "com.android.systemui") Diag.lastPkg = pkg
        if (!store.active || !pkg.startsWith("com.facebook")) return
        val now = System.currentTimeMillis()
        if (now - lastScan < 600) return
        lastScan = now
        val root = rootInActiveWindow
        if (root == null) { Diag.nullRoots++; return }
        Diag.scans++
        nodeCount = 0
        pendingPrice = null
        walk(root, 0)
    }

    private fun walk(n: AccessibilityNodeInfo, depth: Int) {
        if (depth > 50 || nodeCount > 3000) return
        nodeCount++
        Diag.nodes++
        n.contentDescription?.toString()?.let { handle(it) }
        n.text?.toString()?.let { handle(it) }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1)
        }
    }

    private fun handle(raw: String) {
        if (raw.length > 300) return
        Diag.sample(raw)

        var listing = Estimator.parse(raw)
        if (listing == null) {
            // Repli : le prix et le titre sont dans deux textes qui se suivent
            val p = Estimator.parsePrice(raw)
            if (p != null) { pendingPrice = p; pendingAge = 0; return }
            val pp = pendingPrice
            if (pp != null) {
                pendingAge++
                if (raw.length >= 4) { listing = Listing(raw.trim(), pp, ""); pendingPrice = null }
                else if (pendingAge > 2) pendingPrice = null
            }
        }
        if (listing == null) return

        Diag.parsed++
        val deal = Estimator.evaluate(listing, store)
        if (store.insertIfNew(deal) && deal.resale > 0 && deal.profit >= store.minProfit) notify(deal)
    }

    private fun notify(d: Deal) {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val text = "Achat ${d.price.toInt()} → revente ~${d.resale.toInt()} · profit ~${d.profit.toInt()} " +
            "(marge ${d.margin.toInt()} %)" + if (d.risks.isNotEmpty()) "\n⚠ ${d.risks}" else ""
        val nt = Notification.Builder(this, "deals")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle(d.title)
            .setContentText(text.lines().first())
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(d.key.hashCode(), nt)
    }

    override fun onInterrupt() {}
}
