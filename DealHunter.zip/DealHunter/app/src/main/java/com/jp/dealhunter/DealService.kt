package com.jp.dealhunter

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class DealService : AccessibilityService() {

    private class OLine(val text: String, val r: Rect)

    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private val captureRun = Runnable { capture() }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var busy = false
    private var lastScan = 0L
    private var nodeCount = 0
    private var pendingPrice: Double? = null
    private var pendingAge = 0

    override fun onServiceConnected() {
        store = Store(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("deals", "Bonnes affaires", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !::store.isInitialized) return
        Diag.events++
        val pkg = e.packageName?.toString() ?: return
        if (pkg != packageName && pkg != "com.android.systemui") Diag.lastPkg = pkg
        if (!store.active || !pkg.startsWith("com.facebook")) return

        // Capture d'écran + OCR une fois que le défilement s'est calmé
        handler.removeCallbacks(captureRun)
        handler.postDelayed(captureRun, 900)

        // Lecture de l'arbre d'accessibilité
        val now = System.currentTimeMillis()
        if (now - lastScan < 600) return
        lastScan = now
        val root = rootInActiveWindow
        if (root == null) { Diag.nullRoots++; return }
        Diag.scans++
        nodeCount = 0
        pendingPrice = null
        walk(root, 0)
    }

    // ---------- OCR ----------

    private fun capture() {
        if (!store.active || busy || Build.VERSION.SDK_INT < 30) return
        busy = true
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val buf = r.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(buf, r.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        buf.close()
                        if (bmp == null) { busy = false; return }
                        Diag.shots++
                        recognizer.process(InputImage.fromBitmap(bmp, 0))
                            .addOnSuccessListener { t -> busy = false; readOcr(t, bmp.width) }
                            .addOnFailureListener { ex -> busy = false; Diag.lastErr = "OCR: ${ex.message}" }
                    } catch (ex: Exception) {
                        busy = false; Diag.lastErr = ex.toString()
                    }
                }
                override fun onFailure(errorCode: Int) {
                    busy = false; Diag.lastErr = "capture refusée (code $errorCode)"
                }
            })
        } catch (ex: Exception) {
            busy = false; Diag.lastErr = ex.toString()
        }
    }

    private fun readOcr(t: Text, width: Int) {
        val lines = ArrayList<OLine>()
        for (b in t.textBlocks) for (l in b.lines) {
            val r = l.boundingBox ?: continue
            val s = l.text.trim()
            if (s.isNotEmpty()) lines.add(OLine(s, r))
        }
        Diag.ocrLines += lines.size
        lines.forEach { Diag.sample("OCR: " + it.text) }

        val colW = width / 2
        for (pl in lines) {
            if (pl.text.length > 22) continue
            val price = Estimator.priceInLine(pl.text) ?: continue
            val below = lines.filter {
                it !== pl && it.r.top >= pl.r.bottom - 6 && it.r.top - pl.r.bottom < 260 &&
                    abs(it.r.left - pl.r.left) < colW * 0.3 && Estimator.priceInLine(it.text) == null
            }.sortedBy { it.r.top }
            val title = below.firstOrNull()?.text ?: continue
            if (title.length < 3) continue
            val loc = below.getOrNull(1)?.text ?: ""
            record(Listing(title, price, loc))
        }
    }

    // ---------- Arbre d'accessibilité ----------

    private fun walk(n: AccessibilityNodeInfo, depth: Int) {
        if (depth > 50 || nodeCount > 3000) return
        nodeCount++
        Diag.nodes++
        n.contentDescription?.toString()?.let { handle(it) }
        n.text?.toString()?.let { handle(it) }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1)
        }
    }

    private fun handle(raw: String) {
        if (raw.length > 300) return
        Diag.sample(raw)
        var listing = Estimator.parse(raw)
        if (listing == null) {
            val p = Estimator.parsePrice(raw)
            if (p != null) { pendingPrice = p; pendingAge = 0; return }
            val pp = pendingPrice
            if (pp != null) {
                pendingAge++
                if (raw.length >= 4) { listing = Listing(raw.trim(), pp, ""); pendingPrice = null }
                else if (pendingAge > 2) pendingPrice = null
            }
        }
        if (listing != null) record(listing)
    }

    // ---------- Enregistrement ----------

    private fun record(listing: Listing) {
        Diag.parsed++
        val deal = Estimator.evaluate(listing, store)
        if (store.insertIfNew(deal) && deal.resale > 0 && deal.profit >= store.minProfit) notify(deal)
    }

    private fun notify(d: Deal) {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val text = "Achat ${d.price.toInt()} → revente ~${d.resale.toInt()} · profit ~${d.profit.toInt()} " +
            "(marge ${d.margin.toInt()} %)" + if (d.risks.isNotEmpty()) "\n⚠ ${d.risks}" else ""
        val nt = Notification.Builder(this, "deals")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle(d.title)
            .setContentText(text.lines().first())
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(d.key.hashCode(), nt)
    }

    override fun onInterrupt() {}
}
