package com.jp.dealhunter

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.Notification

class DealService : AccessibilityService() {

    private lateinit var store: Store
    private var lastScan = 0L
    private var count = 0

    override fun onServiceConnected() {
        store = Store(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("deals", "Bonnes affaires", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !::store.isInitialized || !store.active) return
        val now = System.currentTimeMillis()
        if (now - lastScan < 700) return
        lastScan = now
        val root = rootInActiveWindow ?: return
        count = 0
        walk(root, 0)
    }

    private fun walk(n: AccessibilityNodeInfo, depth: Int) {
        if (depth > 40 || count > 2500) return
        count++
        n.contentDescription?.toString()?.let { handle(it) }
        n.text?.toString()?.let { handle(it) }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1)
        }
    }

    private fun handle(raw: String) {
        if (raw.length > 300) return
        val listing = Estimator.parse(raw) ?: return
        val deal = Estimator.evaluate(listing, store) ?: return
        if (store.insertIfNew(deal) && deal.profit >= store.minProfit) notify(deal)
    }

    private fun notify(d: Deal) {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val text = "Achat ${d.price.toInt()} → revente ~${d.resale.toInt()} · profit ~${d.profit.toInt()} " +
            "(marge ${d.margin.toInt()} %)" + if (d.risks.isNotEmpty()) "\n⚠ ${d.risks}" else ""
        val nt = Notification.Builder(this, "deals")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle(d.title)
            .setContentText(text.lines().first())
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(d.key.hashCode(), nt)
    }

    override fun onInterrupt() {}
}
